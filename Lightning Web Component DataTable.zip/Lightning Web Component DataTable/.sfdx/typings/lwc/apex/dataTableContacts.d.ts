declare module "@salesforce/apex/dataTableContacts.getContactList" {
  export default function getContactList(param: {filterAppendValue: any}): Promise<any>;
}
